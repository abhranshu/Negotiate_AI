package com.negotiateai.app.data.repository

import android.content.Context
import com.negotiateai.app.data.SessionManager
import com.negotiateai.app.data.model.LoginRequest
import com.negotiateai.app.data.model.RegisterRequest
import com.negotiateai.app.data.model.UserDto
import com.negotiateai.app.data.network.ApiClient
import com.negotiateai.app.feature.settlement.NetworkResult

class AuthRepository(private val context: Context) {
	private val api = ApiClient.getService(context)
	private val sessionManager = SessionManager(context)

	suspend fun login(email: String, password: String): NetworkResult<String> = try {
		val response = api.login(email, password)
		if (response.isSuccessful && response.body() != null) {
			val token = response.body()!!.accessToken
			sessionManager.saveAuthToken(token)
			NetworkResult.Success(token)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Login failed" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}

	suspend fun register(request: RegisterRequest): NetworkResult<UserDto> = try {
		val response = api.register(request)
		if (response.isSuccessful && response.body() != null) {
			NetworkResult.Success(response.body()!!)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Registration failed" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}

	suspend fun currentUser(): NetworkResult<UserDto> = try {
		val response = api.getCurrentUser()
		if (response.isSuccessful && response.body() != null) {
			NetworkResult.Success(response.body()!!)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Failed to load profile" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}
}
