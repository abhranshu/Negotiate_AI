package com.negotiateai.app.data.repository

import android.content.Context
import com.negotiateai.app.data.model.CaseDescriptionUpdate
import com.negotiateai.app.data.model.CaseDto
import com.negotiateai.app.data.model.CaseListItem
import com.negotiateai.app.data.model.CreateCaseRequest
import com.negotiateai.app.data.model.DocumentDto
import com.negotiateai.app.data.model.NegotiationMessageDto
import com.negotiateai.app.data.network.ApiClient
import com.negotiateai.app.feature.settlement.NetworkResult

class CaseRepository(context: Context) {
	private val api = ApiClient.getService(context)

	suspend fun listCases(): NetworkResult<List<CaseListItem>> = try {
		val response = api.getCases()
		if (response.isSuccessful && response.body() != null) {
			NetworkResult.Success(response.body()!!)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Failed to load cases" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}

	suspend fun getCase(caseId: String): NetworkResult<CaseDto> = try {
		val response = api.getCase(caseId)
		if (response.isSuccessful && response.body() != null) {
			NetworkResult.Success(response.body()!!)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Case not found" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}

	suspend fun createCase(request: CreateCaseRequest): NetworkResult<CaseDto> = try {
		val response = api.createCase(request)
		if (response.isSuccessful && response.body() != null) {
			NetworkResult.Success(response.body()!!)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Failed to create case" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}

	suspend fun updateDescription(caseId: String, description: String): NetworkResult<CaseDto> = try {
		val response = api.updateDescription(caseId, CaseDescriptionUpdate(description))
		if (response.isSuccessful && response.body() != null) {
			NetworkResult.Success(response.body()!!)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Failed to update description" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}

	suspend fun getDocuments(caseId: String): NetworkResult<List<DocumentDto>> = try {
		val response = api.getDocuments(caseId)
		if (response.isSuccessful && response.body() != null) {
			NetworkResult.Success(response.body()!!)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Failed to load documents" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}

	suspend fun getMessages(caseId: String): NetworkResult<List<NegotiationMessageDto>> = try {
		val response = api.getMessages(caseId)
		if (response.isSuccessful && response.body() != null) {
			NetworkResult.Success(response.body()!!)
		} else {
			NetworkResult.Error(response.message().ifBlank { "Failed to load messages" })
		}
	} catch (e: Exception) {
		NetworkResult.Error(e.message ?: "Network failure")
	}
}
