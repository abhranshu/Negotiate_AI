package com.negotiateai.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── DESIGN.md tokens ──────────────────────────────────────────────
// Surface
val Surface = Color(0xFFF8F9FA)
val SurfaceDim = Color(0xFFD9DADB)
val SurfaceBright = Color(0xFFF8F9FA)
val SurfaceContainerLowest = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFF3F4F5)
val SurfaceContainer = Color(0xFFEDEEEF)
val SurfaceContainerHigh = Color(0xFFE7E8E9)
val SurfaceContainerHighest = Color(0xFFE1E3E4)
val SurfaceVariant = Color(0xFFE1E3E4)
val SurfaceTint = Color(0xFF096969)

// Text
val OnSurface = Color(0xFF191C1D)
val OnSurfaceVariant = Color(0xFF3F4948)
val InverseSurface = Color(0xFF2E3132)
val InverseOnSurface = Color(0xFFF0F1F2)
val Outline = Color(0xFF6F7979)
val OutlineVariant = Color(0xFFBEC9C8)

// Primary (institutional teal)
val Primary = Color(0xFF004C4C)
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFF006666)
val OnPrimaryContainer = Color(0xFF93E1E0)
val InversePrimary = Color(0xFF86D4D3)
val PrimaryFixed = Color(0xFFA2F0EF)
val PrimaryFixedDim = Color(0xFF86D4D3)
val OnPrimaryFixed = Color(0xFF002020)
val OnPrimaryFixedVariant = Color(0xFF004F4F)

// Secondary
val Secondary = Color(0xFF5B5F63)
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFDDE0E5)
val OnSecondaryContainer = Color(0xFF5F6368)
val SecondaryFixed = Color(0xFFE0E3E8)
val SecondaryFixedDim = Color(0xFFC3C7CC)
val OnSecondaryFixed = Color(0xFF181C20)
val OnSecondaryFixedVariant = Color(0xFF43474C)

// Tertiary
val Tertiary = Color(0xFF3C454C)
val OnTertiary = Color(0xFFFFFFFF)
val TertiaryContainer = Color(0xFF535C64)
val OnTertiaryContainer = Color(0xFFCBD4DD)
val TertiaryFixed = Color(0xFFDBE4ED)
val TertiaryFixedDim = Color(0xFFBFC8D0)
val OnTertiaryFixed = Color(0xFF141D23)
val OnTertiaryFixedVariant = Color(0xFF3F484F)

// Error (muted, institutional)
val Error = Color(0xFFBA1A1A)
val OnError = Color(0xFFFFFFFF)
val ErrorContainer = Color(0xFFFFDAD6)
val OnErrorContainer = Color(0xFF93000A)

// Background
val Background = Color(0xFFF8F9FA)
val OnBackground = Color(0xFF191C1D)

// ── Light scheme (primary mode — gov-tech is light-first) ─────────
private val LightColorScheme = lightColorScheme(
    primary = PrimaryContainer,              // #006666 per DESIGN.md "Primary"
    onPrimary = OnPrimary,
    primaryContainer = PrimaryFixed,         // light teal fill
    onPrimaryContainer = OnPrimaryFixedVariant,
    inversePrimary = InversePrimary,

    secondary = Secondary,
    onSecondary = OnSecondary,
    secondaryContainer = SecondaryContainer,
    onSecondaryContainer = OnSecondaryContainer,

    tertiary = Tertiary,
    onTertiary = OnTertiary,
    tertiaryContainer = TertiaryFixed,
    onTertiaryContainer = OnTertiaryFixedVariant,

    error = Error,
    onError = OnError,
    errorContainer = ErrorContainer,
    onErrorContainer = OnErrorContainer,

    background = Background,
    onBackground = OnBackground,

    surface = Surface,
    onSurface = OnSurface,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = OnSurfaceVariant,
    surfaceTint = SurfaceTint,

    surfaceDim = SurfaceDim,
    surfaceBright = SurfaceBright,
    surfaceContainerLowest = SurfaceContainerLowest,
    surfaceContainerLow = SurfaceContainerLow,
    surfaceContainer = SurfaceContainer,
    surfaceContainerHigh = SurfaceContainerHigh,
    surfaceContainerHighest = SurfaceContainerHighest,

    inverseSurface = InverseSurface,
    inverseOnSurface = InverseOnSurface,

    outline = Outline,
    outlineVariant = OutlineVariant,
)

// ── Dark scheme (fallback — tones flipped for legibility) ─────────
private val DarkColorScheme = darkColorScheme(
    primary = PrimaryFixedDim,               // #86D4D3 on dark
    onPrimary = OnPrimaryFixed,
    primaryContainer = Primary,              // deep teal chip
    onPrimaryContainer = OnPrimaryContainer,
    inversePrimary = Primary,

    secondary = SecondaryFixedDim,
    onSecondary = OnSecondaryFixed,
    secondaryContainer = OnSecondaryFixedVariant,
    onSecondaryContainer = SecondaryFixed,

    tertiary = TertiaryFixedDim,
    onTertiary = OnTertiaryFixed,
    tertiaryContainer = OnTertiaryFixedVariant,
    onTertiaryContainer = TertiaryFixed,

    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = OnErrorContainer,
    onErrorContainer = ErrorContainer,

    background = Color(0xFF111415),
    onBackground = InverseOnSurface,

    surface = Color(0xFF111415),
    onSurface = InverseOnSurface,
    surfaceVariant = OnSurfaceVariant,
    onSurfaceVariant = OutlineVariant,
    surfaceTint = PrimaryFixedDim,

    surfaceDim = Color(0xFF111415),
    surfaceBright = Color(0xFF373A3B),
    surfaceContainerLowest = Color(0xFF0C0F10),
    surfaceContainerLow = OnSurface,
    surfaceContainer = Color(0xFF1D2021),
    surfaceContainerHigh = Color(0xFF272A2B),
    surfaceContainerHighest = InverseSurface,

    inverseSurface = InverseOnSurface,
    inverseOnSurface = InverseSurface,

    outline = Color(0xFF899392),
    outlineVariant = OnSurfaceVariant,
)

// ── Theme entry point ──────────────────────────────────────────────
@Composable
fun NegotiateAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NegotiateAITypography,   // from Type.kt
        shapes = NegotiateAIShapes,           // from Shapes.kt
        content = content
    )
}